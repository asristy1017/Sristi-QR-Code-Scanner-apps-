package applet;

import com.google.zxing.*;
import com.google.zxing.client.j2se.*;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Callback;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

public class QRCodeScannerApp extends Application {

    private static final int WIDTH = 640;
    private static final int HEIGHT = 480;
    private ObjectProperty<BufferedImage> bufferedImageProperty = new SimpleObjectProperty<>();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        StackPane root = new StackPane();
        Scene scene = new Scene(root, WIDTH, HEIGHT);
        
        // Set up camera feed (using JavaFX)
        VideoCapture camera = new VideoCapture(WIDTH, HEIGHT);
        root.getChildren().add(camera.getView());

        // Display information from QR code
        Text infoText = new Text();
        infoText.setFill(Color.WHITE);
        infoText.setStyle("-fx-font-size: 24px;");
        StackPane.setAlignment(infoText, Pos.TOP_CENTER);
        root.getChildren().add(infoText);

        // Button to start scanning process
        Button scanButton = new Button("Scan QR Code");
        scanButton.setStyle("-fx-font-size: 18px;");
        scanButton.setOnAction(e -> startScanning(camera, infoText));
        root.getChildren().add(scanButton);

        scanButton.setTranslateY(100);

        primaryStage.setTitle("QR Code Scanner");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void startScanning(VideoCapture camera, Text infoText) {
        // Start camera feed for scanning QR code
        new Thread(() -> {
            while (camera.isRunning()) {
                // Capture image from the camera feed
                BufferedImage bufferedImage = camera.captureImage();
                if (bufferedImage != null) {
                    // Detect QR code in the image
                    try {
                        Result result = decodeQRCode(bufferedImage);
                        if (result != null) {
                            Platform.runLater(() -> {
                                String scannedContent = result.getText();
                                infoText.setText("Scanned: " + scannedContent);
                                handleScannedContent(scannedContent);
                            });
                        }
                    } catch (NotFoundException e) {
                        // No QR code found, continue scanning
                    }
                }
            }
        }).start();
    }

    // Decodes QR code using ZXing
    private Result decodeQRCode(BufferedImage bufferedImage) throws NotFoundException {
        // Convert bufferedImage to a BinaryBitmap
        BinaryBitmap binaryBitmap = new BinaryBitmap(new HybridBinarizer(new BufferedImageLuminanceSource(bufferedImage)));
        
        // Create a reader for QR codes
        QRCodeReader reader = new QRCodeReader();
        
        // Decode the QR code
        return reader.decode(binaryBitmap);
    }

    // Handle scanned QR code content
    private void handleScannedContent(String content) {
        if (content.startsWith("http://") || content.startsWith("https://")) {
            // Open the URL in the default browser
            try {
                URI uri = new URI(content);
                if (Desktop.isDesktopSupported()) {
                    Desktop.getDesktop().browse(uri);
                }
            } catch (IOException | URISyntaxException e) {
                showErrorAlert("Failed to open the link.");
            }
        } else {
            // Display the QR code data as text
            showInfoAlert("QR Code Content", content);
        }
    }

    // Show info alert dialog
    private void showInfoAlert(String title, String content) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    // Show error alert dialog
    private void showErrorAlert(String message) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // VideoCapture class (for camera feed and capturing images)
    static class VideoCapture {
        private final ObjectProperty<Canvas> canvasProperty = new SimpleObjectProperty<>();
        private boolean isRunning = false;

        public VideoCapture(int width, int height) {
            Canvas canvas = new Canvas(width, height);
            this.canvasProperty.set(canvas);
            isRunning = true;
        }

        public boolean isRunning() {
            return isRunning;
        }

        public void stop() {
            isRunning = false;
        }

        public BufferedImage captureImage() {
            // Simulate capturing an image from the camera feed
            return new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_RGB); // Placeholder for actual image capture logic
        }

        public Canvas getView() {
            return canvasProperty.get();
        }
    }
}